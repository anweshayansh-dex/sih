#!/usr/bin/env bash
echo "================================================================"
echo "         BIS Sahayak - AI Assistant for Indian Standards        "
echo "================================================================"

if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not installed! Please install Node.js from https://nodejs.org/"
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "[INFO] Installing lightweight runtime dependencies..."
    npm install --omit=dev
fi

if [ ! -f ".env" ] && [ -f ".env.example" ]; then
    cp .env.example .env
fi

if command -v xdg-open &> /dev/null; then
    (sleep 2 && xdg-open http://localhost:3000) &
elif command -v open &> /dev/null; then
    (sleep 2 && open http://localhost:3000) &
fi

echo "[INFO] Running BIS Sahayak server at http://localhost:3000..."
npm start
