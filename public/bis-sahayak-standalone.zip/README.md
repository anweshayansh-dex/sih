# BIS Sahayak - Standalone Prototype (SIH PS26107)
Bureau of Indian Standards - AI-Powered Standards & Conformity Assistant

This package is a self-contained, pre-compiled standalone distribution. It can be run locally or shared directly without needing Google AI Studio.

## Quick Start:

### On Windows:
1. Extract all files from `bis-sahayak-standalone.zip`.
2. Double-click `start-windows.bat`.
3. It will install minimal runtime dependencies, launch the server, and automatically open your default browser to `http://localhost:3000`.

### On macOS / Linux:
1. Extract all files: `unzip bis-sahayak-standalone.zip`
2. Run:
```bash
chmod +x start-linux-mac.sh
./start-linux-mac.sh
```

### Manual Run:
```bash
npm install --omit=dev
npm start
```
Open `http://localhost:3000` in any web browser.

## Troubleshooting Extraction:
- **Windows Built-in Extractor**: Right-click `bis-sahayak-standalone.zip` -> select **Extract All...** -> Choose a destination folder and click **Extract**.
- **PowerShell (Terminal)**:
  `Expand-Archive -Path .\bis-sahayak-standalone.zip -DestinationPath .\bis-sahayak`
- **7-Zip / WinRAR**: Right click -> "Extract here" or "Extract to bis-sahayak-standalone/".
