# BIS Sahayak - Standalone Prototype (SIH PS26107)
Bureau of Indian Standards - AI-Powered Standards & Conformity Assistant

This package is a self-contained, pre-compiled standalone distribution. It can be run locally or shared directly without needing Google AI Studio.

## Quick Start:

### On Windows:
Double-click `start-windows.bat`. It will install minimal runtime dependencies, start the server, and automatically open your default browser to `http://localhost:3000`.

### On macOS / Linux:
Run:
```bash
chmod +x start-linux-mac.sh
./start-linux-mac.sh
```

### Manual Run:
```bash
npm install --omit=dev
npm start
```
Open `http://localhost:3000` in any web browser.

## Key Features Tested:
1. Indian Standards (IS Code) semantic search & RAG engine (117+ standards)
2. 6-digit Gold Hallmarking HUID Verifier & Assay lab checker
3. Testing Laboratory Directory (state & category filters)
4. License & Certification Scheme tracker (ISI, CRS, FMCS)
5. Citizen Grievance & Complaint center with sample filing & tracking
6. Multilingual interface in English, Hindi, and Odia
7. High-contrast & accessibility controls
