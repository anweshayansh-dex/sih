@echo off
TITLE BIS Sahayak - Standalone Prototype
COLOR 0B

echo ================================================================
echo          BIS Sahayak - AI Assistant for Indian Standards
echo               Smart India Hackathon (SIH PS26107)
echo ================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    COLOR 0C
    echo [ERROR] Node.js is required to run the local prototype!
    echo Please install Node.js (v18 or higher) from: https://nodejs.org/
    echo Once installed, double-click this file again.
    pause
    exit /b 1
)

if not exist "node_modules\" (
    echo [INFO] First-time setup: Installing lightweight runtime dependencies...
    call npm install --omit=dev
    echo.
)

if not exist ".env" (
    if exist ".env.example" (
        copy .env.example .env >nul
    ) else (
        echo GEMINI_API_KEY=> .env
    )
)

echo [INFO] Starting BIS Sahayak Server on http://localhost:3000...
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:3000"

call npm start
pause
